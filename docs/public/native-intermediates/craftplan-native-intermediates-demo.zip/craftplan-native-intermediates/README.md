# Craftplan: native intermediate production

Open `index.html` for the offline guide, or play `demo.mp4` directly.
The package includes the demo recording and seven screenshots.

1. Define a material recipe and standard yield.
2. Plan the quantity and review suggested input lots.
3. Record actual output and usage, then complete the batch.

Completion consumes raw input lots and stocks the intermediate in one transaction.
Finished products then consume its stocked lot. Actual costs, recipe history,
and supplier-to-customer tracing are preserved.

Example: 800 g wheat + 200 g rye cost $4.40 and yield 950 g of blend.
A loaf uses 400 g and a roll uses 100 g, leaving 450 g.

Available in Craftplan v0.7.5 and later. The recording and screenshots
demonstrate the current interface.
Recorded against an isolated local database with demonstration data. Silent video
with on-screen explanations; idle pauses shortened.
